# Déploiement GitHub Pages (gratuit)

1. Crée un dépôt **public** sur GitHub (ex: `vroomvroom-site`).
2. Envoie `index.html` (et ce README), puis **Commit**.
3. Va dans **Settings → Pages** → *Build and deployment* : choisis **Deploy from a branch**.
4. *Branch* = **main** / *root* (/**/**), puis **Save**.
5. Ton site sera en ligne sous `https://TONPSEUDO.github.io/vroomvroom-site`.
